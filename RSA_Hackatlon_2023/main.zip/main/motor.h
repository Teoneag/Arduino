class Motor {
  public:
    void init();
    void setLeft(int speed);
    void setRight(int speed);
};